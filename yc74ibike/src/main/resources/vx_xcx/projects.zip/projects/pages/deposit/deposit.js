// pages/deposit/deposit.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  deposit:function(){
    var that=this;
    wx.showModal({
      title: '提示',
      content:"是否需要充值押金",
      confirmText:"确认",
      success:function(res){
        //模拟加载的动画
        wx.showLoading({
          title: '充值中',
        })
        var phoneNum=wx.getStorageSync('phoneNum');
        wx.request({
          url: wx.getStorageSync("url")+'/deposit',
          header:{'content-type':"application/x-www-form-urlencoded"},
          method:"POST",
          data:{
            phoneNum:phoneNum
          },
          success:function(res){
            if(res.data.code==1){
              //更改状态码
              getApp().globalData.status=2;
              wx.setStorageSync('status', 2);

              wx.hideLoading(); //隐藏加载条
              wx.navigateTo({
                url: '../identity/identity',
              });
            }else{
              wx.showModal({
                title: '提示',
                content:"押金充值失败",
                showCancel:false
              })
            }
          }
        })
      }
    })
  },
  
})