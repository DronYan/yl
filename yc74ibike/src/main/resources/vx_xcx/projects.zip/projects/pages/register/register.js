// pages/register/register.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    countryCodes:["86","80","84","87"],//手机号国家前缀
    countryCodeIndex:0,
    phoneNum:""
  },
  //国家手机号
  bindCountryCodeChange:function(e){
    //console.log("hello");
    this.setData({
      countryCodeIndex: e.detail.value
    });
  },
  //输入手机号
  inputPhoneNum:function(e){
    this.setData({
      phoneNum:e.detail.value
    })
  },
  //验证码
  genVerifyCode:function(e){
    var index=this.data.countryCodeIndex;
    var countryCodes=this.data.countryCodes[index];
    //电话号码
    var phoneNum=this.data.phoneNum;
    //请求后台，发送验证码短信
    wx.request({
      url: wx.getStorageSync("url")+"/genCode",
      //表单形式传参
      header:{"content-type":"application/x-www-form-urlencoded"},
      data:{
        nationCode:countryCodes,
        phoneNum:phoneNum
      },
      method:"POST",
      success:function(e){
        if(e.data.code==1){
          wx.showToast({
            title: '验证码已发送',
            icon:'success'
          }); 
        }
      }
    });
  },

  //提交
  formSubmit:function(e){
    console.log("事件信息:"+e);
    var phoneNum=e.detail.value.phoneNum;
    var verifyCode=e.detail.value.verifyCode;
    var  openid=wx.getStorageSync('openid')
    console.log("openid:"+openid)
    wx.request({
      url:wx.getStorageSync("url")+"/verify",
      header:{'content-type':"application/x-www-form-urlencoded"},
      method:"POST",
      data:{
        phoneNum:phoneNum,
        verifyCode:verifyCode,
        status:1,
        openid:openid,
        uuid:wx.getStorageSync('uuid')
      },
      success:function(res){
        console.log("手机验证码结果:"+res);
        if(res.data&&res.data.code==0){
          wx.showModal({    //模式对话框
            title: '提示',
            content:"注册用户失败,原因:"+res.data.msg+"!",
            showCancel:false
          })
          return;
        }
        var globalData=getApp().globalData
        globalData.phoneNum=phoneNum  //在全局变量保存当前注册的号码
        wx.setStorageSync('phoneNum', phoneNum);

        //更改状态码
        getApp().globalData.status=1;
        wx.setStorageSync('status', 1)
        //到充值页
        wx.navigateTo({
          url: '../deposit/deposit',
        })
      }
    });

  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})