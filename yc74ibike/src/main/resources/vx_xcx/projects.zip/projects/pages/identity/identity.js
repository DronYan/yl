// pages/identity/identity.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  formSubmit:function(e){
    //获取全局变量的数据
  //  var globalData=getApp().globalData;
    var phoneNum=wx.getStorageSync('phoneNum');
    var name=e.detail.value.name;
    var idNum=e.detail.value.idNum;
    wx.request({
      url: wx.getStorageSync("url")+'/identity',
      header:{'content-type':"application/x-www-form-urlencoded"},
      method:"POST",
      data:{
        phoneNum:phoneNum,
        name:name,
        idNum:idNum
      },
      success:function(res){
        wx.hideLoading();
        //更新全局变量的status属性
       // globalData.status=3;
        wx.setStorageSync('status', 3);

        wx.navigateTo({
          url: '../index/index',
        });
      }
    })

  },


})