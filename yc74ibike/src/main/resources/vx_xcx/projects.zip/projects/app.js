//app.js
App({
  onLaunch: function () {
    //  展示本地存储能力
    // var logs = wx.getStorageSync('logs') || []
    // logs.unshift(Date.now())
    // wx.setStorageSync('logs', logs)
    //wx.setStorageSync('url', "http://localhost:8080/yc74ibike");
    wx.setStorageSync('url', "http://node1:8080/yc74ibike");
    checkLogin();
    
  },


  globalData: {
    status:0,      //当前用户的状态
    userInfo: null
  }

})
function checkLogin(){
  // 登录
  wx.login({
    success: res => {
      // 发送 res.code 到后台换取 openId, sessionKey, unionId
      console.log("checkLogin->res code:"+res.code);
      if(res.code){
        wx.request({
          url:wx.getStorageSync("url")+"/onLogin",
          data:{
            jscode:res.code
          },
          header:{'content-type':"application/x-www-form-urlencoded"},
          method:"POST",
          success:(res)=>{
            if(res.data.code==1){
              var uuid=res.data.obj.uuid;
              var openid=res.data.obj.openid;
              var status=res.data.obj.status;
              var phoneNum=res.data.obj.phoneNum;
              wx.setStorageSync('uuid', uuid);
              wx.setStorageSync('status', status);
              wx.setStorageSync('phoneNum', phoneNum);
              wx.setStorageSync('openid', openid);
              console.log("uuid:"+uuid+" openid:"+openid+" phoneNum:"+phoneNum);
            }
          }
        });
      }else{
        console.log("获取用户登录状况失败"+res.errMsg);
      }
    }
  })
}